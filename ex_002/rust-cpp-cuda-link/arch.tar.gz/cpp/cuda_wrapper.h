#ifndef CUDAWRAPPER_H_
#define CUDAWRAPPER_H_

extern "C" {
  void cuda_wrapper(double* const, size_t);
}

#endif
